import 'package:flutter/material.dart';
import 'package:flutter_application_1/pages/login_page.dart';
import 'package:flutter_application_1/pages/home_page.dart';
import 'package:flutter_application_1/pages/register_page.dart';
import 'package:flutter_application_1/pages/splash_page.dart';
import 'package:flutter_application_1/pages/shopping_page.dart';

Map<String, Widget Function(BuildContext)> appRoutes(
    Function(Locale) changeLanguage) {
  return {
    '/': (context) => const SplashPage(),
    '/login': (context) => const LoginPage(),
    '/home': (context) => HomePage(changeLanguage: changeLanguage),
    '/register': (context) => const RegisterPage(),
    '/shopping': (context) => ShoppingPage(),
  };
}
