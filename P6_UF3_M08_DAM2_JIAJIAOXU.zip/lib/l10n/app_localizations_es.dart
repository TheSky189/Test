import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get login_title => 'Iniciar Sesión';

  @override
  String get register_title => 'Crear Cuenta';

  @override
  String get home_title => '¡Hola, usuario';

  @override
  String get shopping_title => 'Tienda de Viajes';

  @override
  String get city_details => 'Detalles de la Ciudad';

  @override
  String get login_button => 'Iniciar sesión';

  @override
  String get register_button => 'Registrar';

  @override
  String get logout_button => 'Cerrar sesión';

  @override
  String get buy_button => 'Comprar';

  @override
  String get cancel => 'Cancelar';

  @override
  String get delete_button => 'Eliminar';

  @override
  String get explore_cities => 'Explorar Ciudades';

  @override
  String get travel_store => 'Tienda de Viajes';

  @override
  String get hide_cities => 'Ocultar Ciudades';

  @override
  String get hide_store => 'Ocultar Tienda';

  @override
  String get product_price => 'Precio';

  @override
  String get product_date => 'Fecha de alta';

  @override
  String get product_description => 'Descripción';

  @override
  String get country => 'País';

  @override
  String get delete_city => 'Eliminar Ciudad';

  @override
  String get delete_city_confirm => '¿Estás seguro de eliminar esta ciudad?';

  @override
  String get error_login => 'Usuario o contraseña incorrectos';

  @override
  String get error_password => 'Debe tener al menos 7 caracteres y contener letras y números.';

  @override
  String get error_empty_field => 'Este campo no puede estar vacío.';

  @override
  String get register_success => 'Cuenta creada correctamente. Redirigiendo al login...';

  @override
  String get date_format => 'dd/MM/yyyy';

  @override
  String get currency_format => '€';

  @override
  String get delete => 'Eliminar';

  @override
  String get description => 'Descripción';

  @override
  String get cities_zurich_name => 'Zúrich';

  @override
  String get cities_zurich_country => 'Suiza';

  @override
  String get cities_zurich_description => 'Centro financiero de Suiza, con un hermoso lago y vida cultural activa.';

  @override
  String get cities_reykjavik_name => 'Reikiavik';

  @override
  String get cities_reykjavik_country => 'Islandia';

  @override
  String get cities_reykjavik_description => 'Capital de Islandia, famosa por la aurora boreal y aguas termales.';

  @override
  String get cities_oslo_name => 'Oslo';

  @override
  String get cities_oslo_country => 'Noruega';

  @override
  String get cities_oslo_description => 'Ciudad moderna rodeada de fiordos y museos vikingos.';

  @override
  String get cities_berlin_name => 'Berlín';

  @override
  String get cities_berlin_country => 'Alemania';

  @override
  String get cities_berlin_description => 'Capital de Alemania, con una historia fascinante y cultura vibrante.';

  @override
  String get cities_helsinki_name => 'Helsinki';

  @override
  String get cities_helsinki_country => 'Finlandia';

  @override
  String get cities_helsinki_description => 'Ciudad de diseño escandinavo con inviernos nevados y saunas.';
}
