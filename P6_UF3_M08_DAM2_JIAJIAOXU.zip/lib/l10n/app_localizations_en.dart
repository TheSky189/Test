import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get login_title => 'Login';

  @override
  String get register_title => 'Create Account';

  @override
  String get home_title => 'Hello, user';

  @override
  String get shopping_title => 'Travel Store';

  @override
  String get city_details => 'City Details';

  @override
  String get login_button => 'Log in';

  @override
  String get register_button => 'Register';

  @override
  String get logout_button => 'Logout';

  @override
  String get buy_button => 'Buy';

  @override
  String get cancel => 'Cancel';

  @override
  String get delete_button => 'Delete';

  @override
  String get explore_cities => 'Explore Cities';

  @override
  String get travel_store => 'Travel Store';

  @override
  String get hide_cities => 'Hide Cities';

  @override
  String get hide_store => 'Hide Store';

  @override
  String get product_price => 'Price';

  @override
  String get product_date => 'Date Added';

  @override
  String get product_description => 'Description';

  @override
  String get country => 'Country';

  @override
  String get delete_city => 'Delete City';

  @override
  String get delete_city_confirm => 'Are you sure you want to delete this city?';

  @override
  String get error_login => 'Incorrect username or password';

  @override
  String get error_password => 'Must have at least 7 characters and contain letters and numbers.';

  @override
  String get error_empty_field => 'This field cannot be empty.';

  @override
  String get register_success => 'Account successfully created. Redirecting to login...';

  @override
  String get date_format => 'MM/dd/yyyy';

  @override
  String get currency_format => '\$';

  @override
  String get delete => 'Delete';

  @override
  String get description => 'Description';

  @override
  String get cities_zurich_name => 'Zurich';

  @override
  String get cities_zurich_country => 'Switzerland';

  @override
  String get cities_zurich_description => 'Financial center of Switzerland, with a beautiful lake and vibrant cultural life.';

  @override
  String get cities_reykjavik_name => 'Reykjavik';

  @override
  String get cities_reykjavik_country => 'Iceland';

  @override
  String get cities_reykjavik_description => 'Capital of Iceland, famous for the Northern Lights and hot springs.';

  @override
  String get cities_oslo_name => 'Oslo';

  @override
  String get cities_oslo_country => 'Norway';

  @override
  String get cities_oslo_description => 'Modern city surrounded by fjords and Viking museums.';

  @override
  String get cities_berlin_name => 'Berlin';

  @override
  String get cities_berlin_country => 'Germany';

  @override
  String get cities_berlin_description => 'Capital of Germany, with fascinating history and vibrant culture.';

  @override
  String get cities_helsinki_name => 'Helsinki';

  @override
  String get cities_helsinki_country => 'Finland';

  @override
  String get cities_helsinki_description => 'Scandinavian design city with snowy winters and saunas.';
}
