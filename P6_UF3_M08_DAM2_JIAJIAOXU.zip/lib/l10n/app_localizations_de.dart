import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for German (`de`).
class AppLocalizationsDe extends AppLocalizations {
  AppLocalizationsDe([String locale = 'de']) : super(locale);

  @override
  String get login_title => 'Anmelden';

  @override
  String get register_title => 'Konto Erstellen';

  @override
  String get home_title => 'Hallo, Benutzer';

  @override
  String get shopping_title => 'Reisegeschäft';

  @override
  String get city_details => 'Stadt Details';

  @override
  String get login_button => 'Anmelden';

  @override
  String get register_button => 'Registrieren';

  @override
  String get logout_button => 'Abmelden';

  @override
  String get buy_button => 'Kaufen';

  @override
  String get cancel => 'Abbrechen';

  @override
  String get delete_button => 'Löschen';

  @override
  String get explore_cities => 'Städte erkunden';

  @override
  String get travel_store => 'Reisegeschäft';

  @override
  String get hide_cities => 'Städte ausblenden';

  @override
  String get hide_store => 'Geschäft ausblenden';

  @override
  String get product_price => 'Preis';

  @override
  String get product_date => 'Hinzugefügt am';

  @override
  String get product_description => 'Beschreibung';

  @override
  String get country => 'Land';

  @override
  String get delete_city => 'Stadt löschen';

  @override
  String get delete_city_confirm => 'Sind Sie sicher, dass Sie diese Stadt löschen möchten?';

  @override
  String get error_login => 'Falscher Benutzername oder Passwort';

  @override
  String get error_password => 'Muss mindestens 7 Zeichen lang sein und Buchstaben sowie Zahlen enthalten.';

  @override
  String get error_empty_field => 'Dieses Feld darf nicht leer sein.';

  @override
  String get register_success => 'Konto erfolgreich erstellt. Weiterleitung zum Login...';

  @override
  String get date_format => 'dd.MM.yyyy';

  @override
  String get currency_format => '€';

  @override
  String get delete => 'Löschen';

  @override
  String get description => 'Description';

  @override
  String get cities_zurich_name => 'Zürich';

  @override
  String get cities_zurich_country => 'Schweiz';

  @override
  String get cities_zurich_description => 'Finanzzentrum der Schweiz mit einem schönen See und einer lebhaften Kulturszene.';

  @override
  String get cities_reykjavik_name => 'Reykjavik';

  @override
  String get cities_reykjavik_country => 'Island';

  @override
  String get cities_reykjavik_description => 'Hauptstadt von Island, bekannt für Nordlichter und heiße Quellen.';

  @override
  String get cities_oslo_name => 'Oslo';

  @override
  String get cities_oslo_country => 'Norwegen';

  @override
  String get cities_oslo_description => 'Moderne Stadt, umgeben von Fjorden und Wikingermuseen.';

  @override
  String get cities_berlin_name => 'Berlin';

  @override
  String get cities_berlin_country => 'Deutschland';

  @override
  String get cities_berlin_description => 'Hauptstadt von Deutschland mit faszinierender Geschichte und lebendiger Kultur.';

  @override
  String get cities_helsinki_name => 'Helsinki';

  @override
  String get cities_helsinki_country => 'Finnland';

  @override
  String get cities_helsinki_description => 'Skandinavische Designstadt mit schneereichen Wintern und Saunen.';
}
