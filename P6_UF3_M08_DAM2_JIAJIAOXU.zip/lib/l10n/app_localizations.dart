import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_de.dart';
import 'app_localizations_en.dart';
import 'app_localizations_es.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('de'),
    Locale('en'),
    Locale('es')
  ];

  /// No description provided for @login_title.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login_title;

  /// No description provided for @register_title.
  ///
  /// In en, this message translates to:
  /// **'Create Account'**
  String get register_title;

  /// No description provided for @home_title.
  ///
  /// In en, this message translates to:
  /// **'Hello, user'**
  String get home_title;

  /// No description provided for @shopping_title.
  ///
  /// In en, this message translates to:
  /// **'Travel Store'**
  String get shopping_title;

  /// No description provided for @city_details.
  ///
  /// In en, this message translates to:
  /// **'City Details'**
  String get city_details;

  /// No description provided for @login_button.
  ///
  /// In en, this message translates to:
  /// **'Log in'**
  String get login_button;

  /// No description provided for @register_button.
  ///
  /// In en, this message translates to:
  /// **'Register'**
  String get register_button;

  /// No description provided for @logout_button.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout_button;

  /// No description provided for @buy_button.
  ///
  /// In en, this message translates to:
  /// **'Buy'**
  String get buy_button;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @delete_button.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete_button;

  /// No description provided for @explore_cities.
  ///
  /// In en, this message translates to:
  /// **'Explore Cities'**
  String get explore_cities;

  /// No description provided for @travel_store.
  ///
  /// In en, this message translates to:
  /// **'Travel Store'**
  String get travel_store;

  /// No description provided for @hide_cities.
  ///
  /// In en, this message translates to:
  /// **'Hide Cities'**
  String get hide_cities;

  /// No description provided for @hide_store.
  ///
  /// In en, this message translates to:
  /// **'Hide Store'**
  String get hide_store;

  /// No description provided for @product_price.
  ///
  /// In en, this message translates to:
  /// **'Price'**
  String get product_price;

  /// No description provided for @product_date.
  ///
  /// In en, this message translates to:
  /// **'Date Added'**
  String get product_date;

  /// No description provided for @product_description.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get product_description;

  /// No description provided for @country.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get country;

  /// No description provided for @delete_city.
  ///
  /// In en, this message translates to:
  /// **'Delete City'**
  String get delete_city;

  /// No description provided for @delete_city_confirm.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete this city?'**
  String get delete_city_confirm;

  /// No description provided for @error_login.
  ///
  /// In en, this message translates to:
  /// **'Incorrect username or password'**
  String get error_login;

  /// No description provided for @error_password.
  ///
  /// In en, this message translates to:
  /// **'Must have at least 7 characters and contain letters and numbers.'**
  String get error_password;

  /// No description provided for @error_empty_field.
  ///
  /// In en, this message translates to:
  /// **'This field cannot be empty.'**
  String get error_empty_field;

  /// No description provided for @register_success.
  ///
  /// In en, this message translates to:
  /// **'Account successfully created. Redirecting to login...'**
  String get register_success;

  /// No description provided for @date_format.
  ///
  /// In en, this message translates to:
  /// **'MM/dd/yyyy'**
  String get date_format;

  /// No description provided for @currency_format.
  ///
  /// In en, this message translates to:
  /// **'\$'**
  String get currency_format;

  /// No description provided for @delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @description.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get description;

  /// No description provided for @cities_zurich_name.
  ///
  /// In en, this message translates to:
  /// **'Zurich'**
  String get cities_zurich_name;

  /// No description provided for @cities_zurich_country.
  ///
  /// In en, this message translates to:
  /// **'Switzerland'**
  String get cities_zurich_country;

  /// No description provided for @cities_zurich_description.
  ///
  /// In en, this message translates to:
  /// **'Financial center of Switzerland, with a beautiful lake and vibrant cultural life.'**
  String get cities_zurich_description;

  /// No description provided for @cities_reykjavik_name.
  ///
  /// In en, this message translates to:
  /// **'Reykjavik'**
  String get cities_reykjavik_name;

  /// No description provided for @cities_reykjavik_country.
  ///
  /// In en, this message translates to:
  /// **'Iceland'**
  String get cities_reykjavik_country;

  /// No description provided for @cities_reykjavik_description.
  ///
  /// In en, this message translates to:
  /// **'Capital of Iceland, famous for the Northern Lights and hot springs.'**
  String get cities_reykjavik_description;

  /// No description provided for @cities_oslo_name.
  ///
  /// In en, this message translates to:
  /// **'Oslo'**
  String get cities_oslo_name;

  /// No description provided for @cities_oslo_country.
  ///
  /// In en, this message translates to:
  /// **'Norway'**
  String get cities_oslo_country;

  /// No description provided for @cities_oslo_description.
  ///
  /// In en, this message translates to:
  /// **'Modern city surrounded by fjords and Viking museums.'**
  String get cities_oslo_description;

  /// No description provided for @cities_berlin_name.
  ///
  /// In en, this message translates to:
  /// **'Berlin'**
  String get cities_berlin_name;

  /// No description provided for @cities_berlin_country.
  ///
  /// In en, this message translates to:
  /// **'Germany'**
  String get cities_berlin_country;

  /// No description provided for @cities_berlin_description.
  ///
  /// In en, this message translates to:
  /// **'Capital of Germany, with fascinating history and vibrant culture.'**
  String get cities_berlin_description;

  /// No description provided for @cities_helsinki_name.
  ///
  /// In en, this message translates to:
  /// **'Helsinki'**
  String get cities_helsinki_name;

  /// No description provided for @cities_helsinki_country.
  ///
  /// In en, this message translates to:
  /// **'Finland'**
  String get cities_helsinki_country;

  /// No description provided for @cities_helsinki_description.
  ///
  /// In en, this message translates to:
  /// **'Scandinavian design city with snowy winters and saunas.'**
  String get cities_helsinki_description;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['de', 'en', 'es'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'de': return AppLocalizationsDe();
    case 'en': return AppLocalizationsEn();
    case 'es': return AppLocalizationsEs();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
