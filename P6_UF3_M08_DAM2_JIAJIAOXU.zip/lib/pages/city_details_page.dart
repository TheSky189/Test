import 'package:flutter/material.dart';
import 'package:flutter_application_1/l10n/app_localizations.dart';

class CityDetailsPage extends StatelessWidget {
  final Map<String, String> city;
  final Function onDelete; // para eliminar ciudad

  const CityDetailsPage(
      {super.key, required this.city, required this.onDelete});

  void _showDeleteDialog(BuildContext context) {
    final localizations = AppLocalizations.of(context);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          //title: const Text("Eliminar Ciudad"),
          //content: const Text("¿Estas seguro eliminar esta ciudad?"),
          title: Text(localizations.delete_city),
          content: Text(localizations.delete_city_confirm),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              //child: const Text("Cancelar"),
              child: Text(localizations.cancel),
            ),
            TextButton(
              onPressed: () {
                onDelete();
                Navigator.pop(context);
                Navigator.pop(context);
              },
              //child: const Text("Eliminar"),
              child: Text(localizations.delete),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final cityKey = city['name']!.toLowerCase();

    return Scaffold(
      appBar: AppBar(
        //title: Text(city['name']!),
        title: Text(cityKey == "zurich"
            ? localizations.cities_zurich_name
            : cityKey == "reykjavik"
                ? localizations.cities_reykjavik_name
                : cityKey == "oslo"
                    ? localizations.cities_oslo_name
                    : cityKey == "berlin"
                        ? localizations.cities_berlin_name
                        : cityKey == "helsinki"
                            ? localizations.cities_helsinki_name
                            : city['name']!),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/background.jpg"), // Imagen de fondo
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          // Centrar todo el contenido
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center, // Centrar contenido
              crossAxisAlignment:
                  CrossAxisAlignment.center, // Centrar horizontalmente
              children: [
                const SizedBox(height: 20),
                ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: Image.asset(
                    city['image']!,
                    width: 800, // Ajusta el tamaño para que quede centrado
                    height: 500,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    //city['description']!,
                    cityKey == "zurich"
                        ? localizations.cities_zurich_description
                        : cityKey == "reykjavik"
                            ? localizations.cities_reykjavik_description
                            : cityKey == "oslo"
                                ? localizations.cities_oslo_description
                                : cityKey == "berlin"
                                    ? localizations.cities_berlin_description
                                    : cityKey == "helsinki"
                                        ? localizations
                                            .cities_helsinki_description
                                        : city['description']!,
                    style: const TextStyle(fontSize: 18, color: Colors.black87),
                    textAlign: TextAlign.center,
                  ),
                  // Centra el texto
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    _showDeleteDialog(context);
                  },
                  //child: const Text("Eliminar Ciudad"),
                  child: Text(localizations.delete_city),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
