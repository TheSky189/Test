import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_application_1/pages/city_details_page.dart';
import 'package:flutter_application_1/pages/shopping_page.dart';
import 'package:flutter_application_1/l10n/app_localizations.dart';

class HomePage extends StatefulWidget {
  final Function(Locale) changeLanguage;
  const HomePage({super.key, required this.changeLanguage});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _username = "usuario"; // Valor predeterminado
  bool _showCities = false;
  bool _showShopping = false;

  @override
  void initState() {
    super.initState();
    _loadUsername(); // Cargar el usuario al iniciar la pantalla
  }

  Future<void> _loadUsername() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _username = prefs.getString('username') ??
          "usuario"; // Recupera el usuario guardado
    });
  }

  Future<void> _logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    Navigator.pushReplacementNamed(context, '/login');
  }

  final List<Map<String, String>> cities = [
    {
      'name': 'Zúrich',
      'country': 'Suiza',
      'image': 'assets/zurich.jpg',
      'description':
          'Centro financiero de Suiza, con un hermoso lago y vida cultural activa.'
    },
    {
      'name': 'Reikiavik',
      'country': 'Islandia',
      'image': 'assets/reykjavik.jpg',
      'description':
          'Capital de Islandia, famosa por la aurora boreal y aguas termales.'
    },
    {
      'name': 'Oslo',
      'country': 'Noruega',
      'image': 'assets/oslo.jpg',
      'description': 'Ciudad moderna rodeada de fiordos y museos vikingos.'
    },
    {
      'name': 'Berlín',
      'country': 'Alemania',
      'image': 'assets/berlin.jpg',
      'description':
          'Capital de Alemania, con una historia fascinante y cultura vibrante.'
    },
    {
      'name': 'Helsinki',
      'country': 'Finlandia',
      'image': 'assets/helsinki.jpg',
      'description':
          'Ciudad de diseño escandinavo con inviernos nevados y saunas.'
    },
  ];

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(
        //title: Text('¡Hola, $_username!'), // Muestra el nombre del usuario
        title: Text('${localizations.home_title} $_username!'),
        actions: [
          DropdownButton<Locale>(
            icon:
                const Icon(Icons.language, color: Color.fromARGB(255, 0, 0, 0)),
            underline: SizedBox(),
            onChanged: (Locale? locale) {
              if (locale != null) {
                widget.changeLanguage(locale);
              }
            },
            items: const [
              DropdownMenuItem(value: Locale('es'), child: Text('Español')),
              DropdownMenuItem(value: Locale('en'), child: Text('English')),
              DropdownMenuItem(value: Locale('de'), child: Text('Deutsch')),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/background.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 40, vertical: 20),
                    textStyle: const TextStyle(fontSize: 18),
                  ),
                  onPressed: () {
                    setState(() {
                      _showCities = !_showCities;
                      _showShopping = false;
                    });
                  },
                  //child: Text(
                  //_showCities ? "Ocultar Ciudades" : "Explorar Ciudades"),
                  child: Text(_showCities
                      ? localizations.hide_cities
                      : localizations.explore_cities),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 40, vertical: 20),
                    textStyle: const TextStyle(fontSize: 18),
                  ),
                  onPressed: () {
                    setState(() {
                      _showShopping = !_showShopping;
                      _showCities = false;
                    });
                  },
                  child: Text(
                    //_showShopping ? "Ocultar Tienda" : "Tienda de Viajes"),
                    _showShopping
                        ? localizations.hide_store
                        : localizations.travel_store, // Traducción
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: _showCities
                  ? ListView.builder(
                      itemCount: cities.length,
                      itemBuilder: (context, index) {
                        final city = cities[index];
                        return Card(
                          color: Colors.white,
                          margin: const EdgeInsets.all(10),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          child: ListTile(
                            leading: Image.asset(city['image']!,
                                width: 50, height: 50, fit: BoxFit.cover),
                            title: Text(city['name']!,
                                style: const TextStyle(color: Colors.black)),
                            subtitle: Text(city['country']!,
                                style: const TextStyle(color: Colors.black54)),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => CityDetailsPage(
                                    city: city,
                                    onDelete: () {
                                      setState(() {
                                        cities.removeWhere(
                                            (c) => c['name'] == city['name']);
                                      });
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    )
                  : _showShopping
                      ? ShoppingPage()
                      : Container(),
            ),
          ],
        ),
      ),
    );
  }
}
