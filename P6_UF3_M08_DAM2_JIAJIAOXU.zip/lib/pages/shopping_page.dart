import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_application_1/pages/product_detail_page.dart';

class ShoppingPage extends StatelessWidget {
  final List<Map<String, dynamic>> products = [
    {
      'name': 'Mochila de Viaje',
      'price': 49.99,
      'image': 'assets/mochila.jpg',
      'date': DateTime(2024, 3, 5),
      'description':
          'Mochila ligera y resistente para llevar todo lo necesario en tu viaje.'
    },
    {
      'name': 'Almohada de Cuello',
      'price': 19.99,
      'image': 'assets/almohada.jpg',
      'date': DateTime(2024, 3, 1),
      'description':
          'Almohada ergonómica para dormir cómodamente en el avión o coche.'
    },
    {
      'name': 'Adaptador de Enchufe Universal',
      'price': 24.99,
      'image': 'assets/adaptador.jpg',
      'date': DateTime(2024, 2, 20),
      'description':
          'Compatible con más de 150 países, carga tus dispositivos en cualquier parte del mundo.'
    },
    {
      'name': 'Organizador de Equipaje',
      'price': 29.99,
      'image': 'assets/organizador.jpg',
      'date': DateTime(2024, 2, 28),
      'description':
          'Set de 6 bolsas para organizar mejor la ropa y accesorios en la maleta.'
    },
    {
      'name': 'Botella de Agua Reutilizable',
      'price': 15.99,
      'date': DateTime(2024, 3, 10),
      'image': 'assets/botella.jpg',
      'description':
          'Botella térmica para mantener tu bebida fría o caliente durante el viaje.'
    },
    {
      'name': 'Candado para Maleta',
      'price': 9.99,
      'date': DateTime(2024, 2, 25),
      'image': 'assets/candado.jpg',
      'description': 'Candado de seguridad TSA para proteger tu equipaje.'
    },
    {
      'name': 'Cargador Portátil',
      'price': 39.99,
      'date': DateTime(2024, 3, 7),
      'image': 'assets/cargador.jpg',
      'description':
          'Power bank de alta capacidad para cargar tus dispositivos en cualquier lugar.'
    },
    {
      'name': 'Mascarilla para Dormir',
      'price': 12.99,
      'date': DateTime(2024, 2, 28),
      'image': 'assets/mascarilla.jpg',
      'description':
          'Antifaz de seda para descansar mejor durante los viajes largos.'
    },
    {
      'name': 'Auriculares con Cancelación de Ruido',
      'price': 89.99,
      'date': DateTime(2024, 3, 2),
      'image': 'assets/auriculares.jpg',
      'description':
          'Auriculares inalámbricos con cancelación activa de ruido para viajes.'
    },
    {
      'name': 'Kit de Higiene para Viaje',
      'price': 14.99,
      'date': DateTime(2024, 3, 3),
      'image': 'assets/kit_higiene.jpg',
      'description':
          'Mini kit con cepillo de dientes, pasta, jabón y otros esenciales para viajar.'
    },
  ];

  String formatPrice(double price, BuildContext context) {
    Locale locale = Localizations.localeOf(context);
    NumberFormat currencyFormatter =
        NumberFormat.simpleCurrency(locale: locale.toString());
    return currencyFormatter.format(price);
  }

  String formatDate(DateTime date, BuildContext context) {
    Locale locale = Localizations.localeOf(context);
    DateFormat dateFormatter = DateFormat.yMMMMd(locale.toString());
    return dateFormatter.format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tienda de Viajes"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/background.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView.builder(
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return Card(
              color: Colors.white,
              margin: const EdgeInsets.all(10),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              child: ListTile(
                leading: Image.asset(
                  product['image']!,
                  width: 50,
                  height: 50,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Icon(
                      Icons.image_not_supported,
                      size: 50,
                      color: Colors.grey),
                ),
                title: Text(product['name']!,
                    style: const TextStyle(color: Colors.black)),
                subtitle: Text(
                  '${formatDate(product['date'], context)} - ${formatPrice(product['price'], context)}',
                  style: const TextStyle(color: Colors.black54),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProductDetailPage(product: product),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
