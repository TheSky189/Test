/*import 'package:flame/components.dart';
import 'package:flame_forge2d/flame_forge2d.dart';

import 'player.dart';
import 'game.dart';

const coinSize = 2.0;

class Coin extends BodyComponent with ContactCallbacks {
  Coin(Vector2 position, this.sprite)
      : super(
          renderBody: false,
          bodyDef: BodyDef()
            ..position = position
            ..type = BodyType.static,
          fixtureDefs: [
            FixtureDef(CircleShape()..radius = coinSize / 2)..isSensor = true,
          ],
        );

  final Sprite sprite;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    add(SpriteComponent(
      sprite: sprite,
      size: Vector2.all(coinSize),
      anchor: Anchor.center,
    ));
  }

  @override
  void beginContact(Object other, Contact contact) {
    if (other is Player) {
      (game as MyPhysicsGame).coinsCollected++;
      removeFromParent();
    }
  }
}*/
